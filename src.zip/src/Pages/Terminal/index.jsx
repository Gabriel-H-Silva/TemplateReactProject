import * as React from 'react';
import Box from '@mui/material/Box';
import "./style.css";
import Background from './Pages/Frames/Background';


export default function Index() {

  return (
      <Box>
        <Background />
      </Box>
  );
}
