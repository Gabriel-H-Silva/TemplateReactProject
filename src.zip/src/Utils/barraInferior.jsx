import * as React from 'react';
import Box from '@mui/material/Box';


export default function BarraInferior() {

  return (
    <Box className="downBar">

      teste
    </Box>
  );
}
